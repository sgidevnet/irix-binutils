Now: foo/x.h
#include_next "x.h"
