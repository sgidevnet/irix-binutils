#define MSG "hello A"
