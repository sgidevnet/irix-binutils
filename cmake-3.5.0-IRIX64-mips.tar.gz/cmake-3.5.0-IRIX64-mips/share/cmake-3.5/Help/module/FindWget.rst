.. cmake-module:: ../../Modules/FindWget.cmake
